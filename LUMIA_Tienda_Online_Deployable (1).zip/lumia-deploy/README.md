# LUMIA Lingerie — tienda propia

Tienda web desarrollada a medida (HTML/CSS/JS + servidor Node.js nativo, sin constructor de tiendas ni dependencias npm externas).

## Qué incluye esta versión
- Identidad visual oscura: negro `#0D0D0D`, oro `#E6C7A1` y crema `#F7F2EE`.
- Fotos de productos adaptables a su marco con `object-fit: contain`, proporción consistente y centrado para evitar que se corte la prenda.
- Catálogo inicial con los 50 productos/precios del archivo recibido.
- Administración con contraseña verificada en el servidor y cookie HttpOnly.
- Alta/edición de productos, precio, costo, stock y varias fotos por producto.
- Editor de contenido para el anuncio, nombre de marca, títulos, textos, categorías, beneficios, preguntas frecuentes, enlaces de Instagram/WhatsApp y fotos de las secciones principales.
- Catálogo, contenido y stock centralizados para todos los visitantes del mismo servidor.
- Registro de pedidos, validación de stock y descuento de unidades en el servidor.
- Derivación del pedido a WhatsApp; el número puede editarse desde Administración.
- Pedidos guardados en `data/orders.json` y endpoint administrativo `GET /api/admin/orders`.

## Probar en una computadora
1. Instalar Node.js 18 o superior.
2. Copiar `.env.example` como `.env`.
3. En `.env`, poner `ADMIN_PASSWORD=120323MYL` para la prueba inicial. No publiques el archivo `.env` ni compartas la contraseña. Antes de vender al público, cambiala por una contraseña larga y única.
4. Desde la carpeta del proyecto ejecutar `npm start`.
5. Abrir `http://localhost:3000`.

## Publicar un enlace para hacer una prueba con otra persona
El proyecto incluye `render.yaml` para facilitar el despliegue en un servicio compatible con Node.js como Render:
1. Subí la carpeta `lumia-deploy` a un repositorio privado en GitHub.
2. En Render, elegí crear un servicio nuevo desde ese repositorio (Blueprint si aparece disponible) y seleccioná `render.yaml`.
3. En las variables de entorno del servicio, cargá `ADMIN_PASSWORD` con `120323MYL` para la prueba inicial. No escribas la contraseña dentro del HTML ni en el repositorio.
4. Esperá a que termine el despliegue. El alojamiento te asignará una URL HTTPS que podrás compartir con la persona que hará la prueba.
5. Abrí la URL, probá el catálogo y un pedido de prueba; luego entrá a **Administración** para cambiar títulos, fotos, textos y stock.

**Importante sobre el plan gratuito:** el disco de algunos alojamientos gratuitos es temporal. Sirve para probar el flujo, pero los cambios de stock, fotos, contenido y pedidos pueden perderse al reiniciar o redesplegar el servicio. Para usarlo en ventas reales, hay que configurar almacenamiento persistente o migrar los datos a una base de datos administrada y hacer copias de seguridad. La URL pública no se genera hasta que completes el despliegue desde tu cuenta; yo no puedo crear esa cuenta ni publicar en tu nombre desde esta conversación.

## Pagos
Los pedidos se registran en el servidor y se preparan para enviar a WhatsApp. Mercado Pago **todavía no está conectado como cobro automático**; para cobrar dentro de la web hay que integrar credenciales privadas de Mercado Pago en el servidor y configurar el flujo de pago/webhook. Nunca coloques credenciales secretas en el HTML público.

## Seguridad y datos
- La contraseña se configura como variable privada del servidor, no está escrita en el HTML.
- La sesión de administración dura 12 horas y usa cookie HttpOnly/SameSite Strict.
- Protegé `data/products.json`, `data/settings.json` y `data/orders.json`: pueden incluir inventario, fotos y datos de clientes.
- El stock se comparte entre usuarios conectados al mismo servidor y se descuenta al registrar el pedido. En la versión actual, el pedido se considera iniciado y el pago sigue pendiente de confirmación.
