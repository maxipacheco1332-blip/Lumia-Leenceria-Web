'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function loadEnv(file) {
  try { for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) { const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, ''); } } catch (_) {}
}
loadEnv(path.join(__dirname, '.env'));
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');
const PRODUCTS_FILE = path.join(DATA, 'products.json');
const ORDERS_FILE = path.join(DATA, 'orders.json');
const SETTINGS_FILE = path.join(DATA, 'settings.json');
const sessions = new Map();
fs.mkdirSync(DATA, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]');
const DEFAULT_SETTINGS = {announcement:'LUMIA · Lencería para sentirte vos · Atención personalizada',brand:'LUMIA',brandSub:'Lingerie · Tu esencia',heroEyebrow:'Una forma de sentirte',heroTitle1:'Tu esencia.',heroTitle2:'Tu intimidad.',heroCopy:'Prendas elegidas para acompañarte en cada versión de vos. Encontrá ese conjunto, básico o pijama que te haga sentir cómoda, segura y auténtica.',heroNote:'La belleza también está en cómo te sentís.',sticker:'Elegida\npara vos',heroButton:'Descubrir la colección',instagram:'Lumia_lingeriee',whatsapp:'543815994992',collectionEyebrow:'La selección LUMIA',collectionTitle:'Encontrá tu favorito',collectionCopy:'Explorá las prendas disponibles y elegí según tu estilo. Los colores, talles y cantidades se muestran de acuerdo con el inventario cargado.',storyEyebrow:'La esencia de LUMIA',storyTitle:'Sentirte bien también es una forma de elegirte.',storyCopy:'En LUMIA creemos que la lencería no tiene una sola forma de ser. Puede ser delicada, cómoda, sensual, simple o todo eso a la vez. Queremos acompañarte con opciones para distintos gustos y momentos, sin reglas y sin exigencias.\n\nElegí lo que te represente. Lo importante es cómo te hace sentir.',faqEyebrow:'Estamos para ayudarte',faqTitle:'Comprar con confianza',helpLabel:'¿Te ayudamos? ↗',footerCopy:'Prendas para elegirte, a tu manera.',benefit1Title:'Elegí a tu manera',benefit1Copy:'Modelos, talles y colores disponibles',benefit2Title:'Atención cercana',benefit2Copy:'Te ayudamos a encontrar tu opción',benefit3Title:'Compra simple',benefit3Copy:'Armá tu pedido y consultanos',cat1Sub:'01 · Para todos los días',cat1Title:'Conjuntos ↗',cat2Sub:'02 · Tus básicos',cat2Title:'Bombachas ↗',cat3Sub:'03 · Tu momento',cat3Title:'Pijamas ↗',cat4Sub:'04 · Complementos',cat4Title:'Accesorios ↗',faq1Title:'¿Cómo elijo mi talle?',faq1Copy:'Consultanos por Instagram antes de confirmar tu pedido. Te ayudamos a revisar las opciones disponibles de cada modelo.',faq2Title:'¿Los productos están disponibles?',faq2Copy:'El stock se consulta en el catálogo central y se actualiza al registrar cada pedido. Te confirmaremos la preparación por WhatsApp.',faq3Title:'¿Cómo hago mi pedido?',faq3Copy:'Agregá los productos a tu bolsa, completá tus datos y generá un mensaje de pedido para enviarlo por WhatsApp o copiarlo para contactarnos.',heroImage:'',storyImage:''};
if (!fs.existsSync(SETTINGS_FILE)) writeJSON(SETTINGS_FILE, DEFAULT_SETTINGS);
if (!ADMIN_PASSWORD) console.warn('AVISO: configurá ADMIN_PASSWORD en .env antes de publicar.');

function readJSON(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; } }
function writeJSON(file, value) { const temp = file + '.tmp'; fs.writeFileSync(temp, JSON.stringify(value, null, 2)); fs.renameSync(temp, file); }
function send(res, status, data, headers={}) { res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff', ...headers }); res.end(JSON.stringify(data)); }
function cookieMap(req) { return Object.fromEntries((req.headers.cookie || '').split(';').map(s=>s.trim()).filter(Boolean).map(s=>{const i=s.indexOf('=');return [s.slice(0,i),decodeURIComponent(s.slice(i+1))]})); }
function isAdmin(req) { const token = cookieMap(req).lumia_admin; const exp = sessions.get(token); if (!token || !exp || exp < Date.now()) { if (token) sessions.delete(token); return false; } return true; }
function parseBody(req, limit=30*1024*1024) { return new Promise((resolve,reject)=>{let size=0, chunks=[];req.on('data',c=>{size+=c.length;if(size>limit){reject(new Error('El archivo enviado supera el límite permitido.'));req.destroy();}else chunks.push(c)});req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}'))}catch(_){reject(new Error('JSON inválido.'))}});req.on('error',reject)}); }
function safeEqual(a,b) { const aa=Buffer.from(String(a||'')), bb=Buffer.from(String(b||'')); return aa.length===bb.length && crypto.timingSafeEqual(aa,bb); }
function makeOrderId() { return 'LM-' + new Date().toISOString().slice(2,10).replace(/-/g,'') + '-' + crypto.randomBytes(3).toString('hex').toUpperCase(); }
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.ico':'image/x-icon'};

const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method==='GET' && url.pathname==='/api/health') return send(res,200,{ok:true,service:'LUMIA Store API'});
    if (req.method==='GET' && url.pathname==='/api/products') return send(res,200,readJSON(PRODUCTS_FILE,[]));
    if (req.method==='GET' && url.pathname==='/api/settings') return send(res,200,{...DEFAULT_SETTINGS,...readJSON(SETTINGS_FILE,{})});
    if (req.method==='PUT' && url.pathname==='/api/settings') {
      if (!isAdmin(req)) return send(res,401,{error:'La sesión de administración venció. Ingresá nuevamente.'});
      const body=await parseBody(req); if(!body || typeof body!=='object' || Array.isArray(body)) return send(res,400,{error:'Configuración inválida.'});
      const settings={...DEFAULT_SETTINGS}; for(const key of Object.keys(DEFAULT_SETTINGS)){if(typeof body[key]==='string')settings[key]=body[key].slice(0,key.endsWith('Image')?12*1024*1024:5000);}
      writeJSON(SETTINGS_FILE,settings); return send(res,200,{ok:true});
    }
    if (req.method==='POST' && url.pathname==='/api/admin/login') {
      const body=await parseBody(req,100000);
      if (!ADMIN_PASSWORD) return send(res,503,{error:'Falta configurar la contraseña de administración en el servidor.'});
      if (!safeEqual(body.password,ADMIN_PASSWORD)) { await new Promise(r=>setTimeout(r,350)); return send(res,401,{error:'Contraseña incorrecta.'}); }
      const token=crypto.randomBytes(32).toString('hex'); sessions.set(token,Date.now()+12*60*60*1000);
      const secure=process.env.NODE_ENV==='production' ? '; Secure' : '';
      return send(res,200,{ok:true},{'Set-Cookie':`lumia_admin=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${secure}`});
    }
    if (req.method==='POST' && url.pathname==='/api/admin/logout') {
      const token=cookieMap(req).lumia_admin; if(token)sessions.delete(token);
      return send(res,200,{ok:true},{'Set-Cookie':'lumia_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
    }
    if (req.method==='PUT' && url.pathname==='/api/products') {
      if (!isAdmin(req)) return send(res,401,{error:'La sesión de administración venció. Ingresá nuevamente.'});
      const products=await parseBody(req); if(!Array.isArray(products))return send(res,400,{error:'El catálogo debe ser una lista de productos.'});
      const seen=new Set();
      for(const p of products){if(!p || p.id==null || !String(p.name||'').trim() || !Number.isFinite(Number(p.price)) || Number(p.price)<0 || !Number.isFinite(Number(p.initialStock)) || Number(p.initialStock)<0)return send(res,400,{error:'Hay un producto con datos inválidos.'});const id=String(p.id);if(seen.has(id))return send(res,400,{error:'Hay códigos internos duplicados.'});seen.add(id);}
      writeJSON(PRODUCTS_FILE,products); return send(res,200,{ok:true,count:products.length});
    }
    if (req.method==='POST' && url.pathname==='/api/orders') {
      const body=await parseBody(req,2*1024*1024); if(!Array.isArray(body.items)||!body.items.length)return send(res,400,{error:'La bolsa está vacía.'});
      const products=readJSON(PRODUCTS_FILE,[]); const normalized=[];
      for(const item of body.items){const p=products.find(x=>String(x.id)===String(item.id));const qty=Number(item.qty);if(!p||!Number.isInteger(qty)||qty<1)return send(res,400,{error:'Hay un producto o cantidad inválida. Actualizá la página.'});if(Number(p.initialStock)<qty)return send(res,409,{error:`Stock insuficiente para ${p.name}. Actualizá la página y probá otra vez.`});normalized.push({id:String(p.id),name:p.name,sku:p.sku||'',size:p.size||'',color:p.color||'',qty,unitPrice:Number(p.price)||0,lineTotal:(Number(p.price)||0)*qty});}
      // All stock validation occurs before any deductions, so a failed order cannot partially consume stock.
      for(const line of normalized){const p=products.find(x=>String(x.id)===line.id);p.initialStock=Number(p.initialStock)-line.qty;}
      writeJSON(PRODUCTS_FILE,products);
      const order={orderId:makeOrderId(),createdAt:new Date().toISOString(),status:'pedido iniciado por WhatsApp; pago pendiente de confirmación',customer:{name:String(body.customer?.name||'').slice(0,120),contact:String(body.customer?.contact||'').slice(0,120),delivery:String(body.customer?.delivery||'A coordinar').slice(0,100),note:String(body.customer?.note||'').slice(0,1000)},items:normalized,total:normalized.reduce((s,x)=>s+x.lineTotal,0)};
      const orders=readJSON(ORDERS_FILE,[]);orders.push(order);writeJSON(ORDERS_FILE,orders);
      return send(res,201,{ok:true,orderId:order.orderId,total:order.total,products});
    }
    if (req.method==='GET' && url.pathname==='/api/admin/orders') { if(!isAdmin(req))return send(res,401,{error:'No autorizado.'});return send(res,200,readJSON(ORDERS_FILE,[])); }
    if (req.method==='GET' && url.pathname.startsWith('/api/')) return send(res,404,{error:'Ruta API inexistente.'});
    let requested=decodeURIComponent(url.pathname); if(requested==='/'||requested==='')requested='/index.html';
    const file=path.resolve(PUBLIC,'.'+requested); if(!file.startsWith(path.resolve(PUBLIC)+path.sep) && file!==path.resolve(PUBLIC,'index.html'))return send(res,403,{error:'Acceso denegado.'});
    fs.readFile(file,(err,content)=>{if(err){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('No encontrado');return;}res.writeHead(200,{'Content-Type':mime[path.extname(file).toLowerCase()]||'application/octet-stream','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','Cache-Control':path.extname(file)==='.html'?'no-cache':'public, max-age=3600'});res.end(content);});
  } catch(err) { console.error(err); if(!res.headersSent)send(res,500,{error:err.message||'Error interno del servidor.'}); }
});
server.listen(PORT,'0.0.0.0',()=>console.log(`LUMIA Store escuchando en puerto ${PORT}`));
